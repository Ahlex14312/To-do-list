<?php
  
  // Include database file
  include 'task.php';

  $taskObj = new Task();

  // Delete record from table
  if(isset($_GET['deleteId']) && !empty($_GET['deleteId'])) {
      $deleteId = $_GET['deleteId'];
      $taskObj->deleteRecord($deleteId);
  }
     
?> 
<!doctype html>
<html lang="en">
  <head>
  	<title>To-Do-List</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700,800,900" rel="stylesheet">
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
		<link rel="stylesheet" href="style.css">
  </head>
  <style>

  </style>
  <body>
		
		<div class="wrapper d-flex align-items-stretch">
			<nav id="sidebar">
				<div class="p-4 pt-5">
		  		<a href="index.php" class="img logo rounded-circle mb-5" style="background-image: url(images/background.png);"></a>
	        <ul class="list-unstyled components mb-5">
	          <li class="active">
	            <a href="#homeSubmenu" data-toggle="collapse" aria-expanded="false"><img style="height:20px;" src="https://cdn0.iconfinder.com/data/icons/3-colors-outline/500/Keep-128.png">      Keep</a>
	          </li>
	          <li>
	              <a href="trash.php"><img style="height:20px;" src="https://cdn0.iconfinder.com/data/icons/ecology-69/64/recycle-bin-garbage-trash-256.png" alt=""> Trash</a>
	          </li>
	        </ul>
	      </div>
    	</nav>

        <!-- Page Content  -->
      <div id="content" class="p-4 p-md-5">

        <nav class="navbar navbar-expand-lg navbar-light bg-light">
          <div class="container-fluid">

            <button type="button" id="sidebarCollapse" class="btn btn-primary">
              <i class="fa fa-bars"></i>
              <span class="sr-only">Toggle Menu</span>
            </button>
            <button class="btn btn-dark d-inline-block d-lg-none ml-auto" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <i class="fa fa-bars"></i>
            </button>

            <div class="collapse navbar-collapse" id="navbarSupportedContent">
              <ul class="nav navbar-nav ml-auto">
                <li class="nav-item active">
                    <a href="create.php" class="btn btn-primary" style="float:left;">Add New Task</a>
                </li>
              </ul>
            </div>
          </div>
        </nav>
        <table class="table table-hover">
    <thead>
      <tr>
      <th>Status</th>
        <th>Task Number</th>
        <th>Task</th>
        <th>Task Added<th>
        <th>Action</th>
      </tr>
    </thead>
    <tbody class="table table-hover">
        <?php 
          $tasks = $taskObj->displayData(); 
          foreach($tasks as $task): ?>
          <?php
          if ($task >= 1):
          ?>
        <tr>  
        <td> <input type="checkbox" class="checkbox"> </td>
          <td><?php echo $task['id'] ?></td>
          <td><?php echo $task['task'] ?></td>
          <td><?php echo $task['date_added']?></td>
          <td></td>
          <td>
            <a href="update.php?editId=<?php echo $task['id'] ?>" style="color:green">
              <i class="fa fa-pencil" aria-hidden="true"></i></a> &nbsp;&nbsp;
            <a href="index.php?deleteId=<?php echo $task['id'] ?>" style="color:red">
              <i class="fa fa-trash" aria-hidden="true"></i>
            </a>
        </td>
        </tr>
        <?php
        else:
        ?>
        <p>No Records Found</p>
        <?php endif; ?>
        <?php endforeach; ?>

    </tbody>
  </table>
</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

<script>
$('.checkbox').change(function(){
  if (this.checked){
    $(this).parent().parent().css("text-decoration","line-through");
  }else{
    $(this).parent().parent().css("text-decoration","none");
  }
})
</script>
</body>
</html>
