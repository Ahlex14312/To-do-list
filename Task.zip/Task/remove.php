<?php
 
	require_once 'task.php';
 
	if(ISSET($_REQUEST['id'])){
		$task = $_REQUEST['id'];
		$query=mysqli_query($conn, "SELECT * FROM `task` WHERE `id` = '$id'") or die(mysqli_error());
		$fetch=mysqli_fetch_array($query);
 
		mysqli_query($conn, "INSERT INTO `trash` VALUES('$fetch[task]')") or die(mysqli_error());
		mysqli_query($conn, "DELETE FROM `task` WHERE `id` = '$id'") or die(mysqli_error());
		header('location:index.php');
	}
 
?>