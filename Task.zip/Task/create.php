
<!-- <!doctype html>
<html lang="en">
<head>
<title>To-Do-List</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

	<link href="https://fonts.googleapis.com/css?family=Lato:300,400,700&display=swap" rel="stylesheet">

	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" href="style.css">
</head>
<body>
	<section class="ftco-section">
		<div class="container">
			<div class="row justify-content-center">
			</div>
			<div class="row justify-content-center">
				<div class="col-md-12 col-lg-10">
					<div class="wrap d-md-flex">
						<div class="img" style="background-image: url(background.jpg);">
						</div>
						<div class="login-wrap p-4 p-md-5">
							<div class="d-flex">
								<div class="w-100">
									<h3 class="mb-4">Create Task</h3>
								</div>
								<div class="w-100">
									<p class="social-media d-flex justify-content-end">
										<a href="#"
											class="social-icon d-flex align-items-center justify-content-center"><span
												class="fa fa-facebook"></span></a>
										<a href="#"
											class="social-icon d-flex align-items-center justify-content-center"><span
												class="fa fa-twitter"></span></a>
									</p>
								</div>
							</div>
                            <form action="create.php" method="POST">
    <div class="form-group">
      <label for="task">Task</label>
      <input type="text" class="form-control" name="task" placeholder="Enter task" required="">
    </div>
    <input type="submit" name="submit" class="btn btn-primary" style="float:right;" value="Submit">
  </form>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
</body>
</html>  --> 
 <?php

  // Include database file
  include 'task.php';

  $taskObj = new Task();

  // Insert Record in customer table
  if(isset($_POST['submit'])) {
    $taskObj->insertData($_POST);
  }
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css"
        integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"
        integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous">
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous">
    </script>
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300&display=swap" rel="stylesheet">
    <title>Crudniter</title>
	<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.min.css">
</head>

<body>
    <style>
    body {
        background: linear-gradient(to bottom, rgba(0, 0, 0, 0.45) 100%, transparent),
            url(https://www.theladders.com/wp-content/uploads/to-do-list-190702.jpg);
        background-size: cover, cover;
        background-position: center, center;
        height: 100vh;
        width: 100%;
        overflow: hidden;
        font-family: 'Poppins', sans-serif;
    }

    input:focus,
    input.form-control:focus {
        border: 2px rgba(145, 135, 238, 1) solid;
        outline: none !important;
        outline-width: 0 !important;
        box-shadow: none;
        -moz-box-shadow: none;
        -webkit-box-shadow: none;
    }
    </style>
  
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="card" style="width: 50rem; height: 15rem;">
                <div class="card-body bg-light">
				<h3>Add New Task
			</h3>
			<br>
			<form action="create.php" method="POST">
    <div class="form-group">
      <label for="task">Task</label>
      <input type="text" class="form-control" name="task" placeholder="Enter task" required="">
    </div>
    <input type="submit" name="submit" class="btn btn-warning" style="float:right;" value="Submit">
  </form>
                </div>
            </div>
        </div>
    </div>
</body>
</html> 